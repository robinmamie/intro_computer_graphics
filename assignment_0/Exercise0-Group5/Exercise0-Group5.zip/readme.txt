# Assignment 0

Changed the second line so that the output is turquoise (0 255 255).
The choice of the color was made by one student under the wise advice of the other two.

Charline 30%
Markus 30%
Robin 40%
