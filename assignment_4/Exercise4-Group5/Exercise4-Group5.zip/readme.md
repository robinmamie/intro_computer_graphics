# Assignment 4

No difficulty was encountered during the set up of the OpenGL exercise framework.

Every team member tried this setup on its own.

Ding Markus 100%
Mamie Robin 100%
Montial Charline 100%
