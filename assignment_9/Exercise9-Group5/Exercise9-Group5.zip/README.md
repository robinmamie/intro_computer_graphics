# Assignment 9

The assignment was made without encountering any problem.
The instructions were well written and very clear, so we simply had to implement what was instructed.

## Contributions

Ding Markus 30%
Mamie Robin 40%
Montial Charline 30%
