# Assignment 1

Apart from the derivations explained in `TheoryExercise.pdf`, the core of our work was to understand how the other files were used by the raytracer (e.g. in `Sphere.cpp`, as advised by the instructions).

Ding Markus 35%
Mamie Robin 30%
Montial Charline 35%
