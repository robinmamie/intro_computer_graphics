# Assignment 2

No difficulty was encountered during the implementation of this part, thanks to crystal clear instructions and a good team work.

Ding Markus 30%
Mamie Robin 35%
Montial Charline 35%
